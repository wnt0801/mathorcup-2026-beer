# MathorCup 候选提交材料 v3

推荐论文：[results/competition_paper.pdf](results/competition_paper.pdf)。
结果入口：[results/START_HERE.md](results/START_HERE.md)。
复现说明：[REPRODUCIBILITY.md](REPRODUCIBILITY.md)。
评分口径：[results/Q1_SCORING_SCOPE.md](results/Q1_SCORING_SCOPE.md)。

原始0–6强度未还原，Stale hops仅为弱模型代理，五项汇总公式未验证。当前归档就是唯一推荐支撑包，未包含任何历史版本、缓存或原机器绝对路径日志。
