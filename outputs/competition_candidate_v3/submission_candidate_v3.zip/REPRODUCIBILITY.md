# 复现

从归档根目录运行，Python3.13；先创建新虚拟环境并安装requirements_competition.txt。

Windows PowerShell：
```powershell
py -3.13 -m venv .venv
& ./.venv/Scripts/python.exe -m pip install -r requirements_competition.txt
& ./.venv/Scripts/python.exe scripts/run_review.py
```

macOS/Linux（仅提供命令，不代表在这些系统实跑）：
```bash
python3.13 -m venv .venv
.venv/bin/python -m pip install -r requirements_competition.txt
.venv/bin/python scripts/run_review.py --font /path/to/ChineseTrueType.ttf
```

默认每次创建新的outputs/reproduction_时间戳目录，构建、验证、打包自动使用同一目录。已提供的results目录不会被覆盖。独立核验当前结果：python scripts/verify_competition.py --output results。输出含已冻结训练CV选择及历史预测比较文件，因此不声称只由附件重新选择全部模型。

需要中文TrueType字体。可用--font或MATHORCUP_CJK_FONT指定；没有可用中文字形时明确报错。系统字体不随包分发。

模型按200/50固定划分训练，种子42；参数不按已查看测试集继续选择。复查Notebook仅读结果，不替代完整脚本。归档内SUPPORT_MANIFEST.json记录每个文件的SHA256，JSON运行位置已作明确的可移植化处理，数值结果未改写。
