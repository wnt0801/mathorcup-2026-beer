# 当前材料入口

[推荐论文](competition_paper.pdf) · [可编辑论文](competition_paper.md)

[三问对应关系](TASK_ALIGNMENT.md) · [评分口径](Q1_SCORING_SCOPE.md)

[运行命令](../REPRODUCIBILITY.md) · [审核总结](../REVIEW_SUMMARY.md)

结果复查Notebook在review_notebooks/；完整训练入口为scripts/run_review.py。
